package kr.green.port.vo;

import lombok.Data;

@Data
public class LikesVO {
	private int li_num;
	private int li_state;
	private int li_bd_num;
	private String li_me_id;
}
