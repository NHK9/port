package kr.green.port.vo;

import lombok.Data;

@Data
public class OptionVO {
	private int op_num;
	private String op_colnsize;
	private int op_amount;
	private String op_pr_code;
}
