package kr.green.port.vo;

import lombok.Data;

@Data
public class CategoryVO {
	private String cg_name;
}
